﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using DTO;


namespace DAL
{
    public class DALNhanVien
    {
        private string connectionString = "Data Source=MSI;Initial Catalog=111;Integrated Security=True";

        public List<DTONhanVien> Get_NhanVien()
        {
            List<DTONhanVien> nhanvien = new List<DTONhanVien>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM NHAN_VIEN";
                SqlCommand scmd = new SqlCommand(query, conn);
                SqlDataReader reader = scmd.ExecuteReader();

                while (reader.Read())
                {
                    // Tạo một đối tượng Nhân viên mới và nạp dữ liệu từ đối tượng đọc
                    DTONhanVien dTONhanVien = new DTONhanVien
                    {
                        MaNV = reader["MaNV"].ToString(),
                        HoTen = reader["HoTen"].ToString(),
                        NgaySinh = DateTime.Parse(reader["NgaySinh"].ToString()),
                        DiaChi = reader["DiaChi"].ToString(),
                        SDT = reader["SDT"].ToString(),
                        GioiTinh = reader["GioiTinh"].ToString(),
                        SoGioLam = int.Parse(reader["SoGioLam"].ToString()),
                        MucLuong = decimal.Parse(reader["MucLuong"].ToString()),
                        ChucVu = reader["ChucVu"].ToString()
                    };
                    nhanvien.Add(dTONhanVien); // Thêm đối tượng vào danh sách
                }
            }
            return nhanvien;

        }
        public bool Add_NhanVien(DTONhanVien nhanVien)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO NHAN_VIEN VALUES (@MaNV, @HoTen, @NgaySinh, @DiaChi, @SDT, @GioiTinh, @SoGioLam, @MucLuong, @ChucVu)";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@MaNV", nhanVien.MaNV);
                cmd.Parameters.AddWithValue("@HoTen", nhanVien.HoTen);
                cmd.Parameters.AddWithValue("@NgaySinh", nhanVien.NgaySinh);
                cmd.Parameters.AddWithValue("@DiaChi", nhanVien.DiaChi);
                cmd.Parameters.AddWithValue("@SDT", nhanVien.SDT);
                cmd.Parameters.AddWithValue("@GioiTinh", nhanVien.GioiTinh);
                cmd.Parameters.AddWithValue("@SoGioLam", nhanVien.SoGioLam);
                cmd.Parameters.AddWithValue("@MucLuong", nhanVien.MucLuong);
                cmd.Parameters.AddWithValue("@ChucVu", nhanVien.ChucVu);

                return cmd.ExecuteNonQuery() > 0;
            }
        }
        public bool Update_NhanVien(DTONhanVien nhanVien) 
        { 
            using (SqlConnection conn = new SqlConnection(connectionString)) 
            { 
                conn.Open(); 
                string query = "UPDATE NHAN_VIEN SET HoTen = @HoTen, NgaySinh = @NgaySinh, DiaChi = @DiaChi, SDT = @SDT, GioiTinh = @GioiTinh, SoGioLam = @SoGioLam, MucLuong = @MucLuong, ChucVu = @ChucVu WHERE MaNV = @MaNV"; 
                SqlCommand cmd = new SqlCommand(query, conn); 
                cmd.Parameters.AddWithValue("@MaNV", nhanVien.MaNV); 
                cmd.Parameters.AddWithValue("@HoTen", nhanVien.HoTen); 
                cmd.Parameters.AddWithValue("@NgaySinh", nhanVien.NgaySinh); 
                cmd.Parameters.AddWithValue("@DiaChi", nhanVien.DiaChi); 
                cmd.Parameters.AddWithValue("@SDT", nhanVien.SDT); 
                cmd.Parameters.AddWithValue("@GioiTinh", nhanVien.GioiTinh); 
                cmd.Parameters.AddWithValue("@SoGioLam", nhanVien.SoGioLam); 
                cmd.Parameters.AddWithValue("@MucLuong", nhanVien.MucLuong); 
                cmd.Parameters.AddWithValue("@ChucVu", nhanVien.ChucVu); 
                
                return cmd.ExecuteNonQuery() > 0;
            }
        }
        public bool Delete_NhanVien(string maNV)
        { 
            using (SqlConnection conn = new SqlConnection(connectionString)) 
            { 
                conn.Open();
                string query = "DELETE FROM NHAN_VIEN WHERE MaNV = @MaNV"; 
                SqlCommand cmd = new SqlCommand(query, conn); 
                cmd.Parameters.AddWithValue("@MaNV", maNV); 
                
                return cmd.ExecuteNonQuery() > 0;
            } 
        }
    }
}
