﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new frmStaff());
            //Application.Run(new frmAdmin());
            //Application.Run(new frmAdminCustomer());
            //Application.Run(new frmAdminPhim());
            Application.Run(new frmAdminStaff());
            //Application.Run(new frmLogin());
            // Application.Run(new frmSeat());
        }
    }
}
