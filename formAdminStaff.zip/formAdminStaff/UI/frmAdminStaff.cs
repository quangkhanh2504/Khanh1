﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using BLL;
using DTO;


namespace UI
{
    public partial class frmAdminStaff : Form
    {
        // Khởi tạo đối tượng BLL để xử lý logic nghiệp vụ
        private BLLNhanVien bLLNhanVien = new BLLNhanVien();
        
        public frmAdminStaff()
        {
            InitializeComponent();
            LoadData();
        }
        
        private void LoadData()
        {
            dgvDSNV.DataSource = bLLNhanVien.Get_AllNhanVien(); // Gán dữ liệu cho DataGridView
                                                               
            dgvDSNV.AlternatingRowsDefaultCellStyle.BackColor = Color.LightPink;  // Màu cho các dòng lẻ
            dgvDSNV.DefaultCellStyle.BackColor = Color.White;  // Màu cho các dòng chẵn
            
            dgvDSNV.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // Căn giữa
            // Căn giữa tên cột: 
            foreach (DataGridViewColumn column in dgvDSNV.Columns)
            {
                column.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

        }

        private void dgvDSNV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Đảm bảo không nhấp vào tiêu đề cột
            { 
                DataGridViewRow row = dgvDSNV.Rows[e.RowIndex];

                // Gán giá trị từ các ô trong DataGridView vào các TextBox
                txtMaNV.Text = row.Cells["MaNV"].Value.ToString();
                txtHoTen.Text = row.Cells["HoTen"].Value.ToString();
                txtSDT.Text = row.Cells["SDT"].Value.ToString(); 
                txtNgaySinh.Text = DateTime.Parse(row.Cells["NgaySinh"].Value.ToString()).ToString("dd/MM/yyyy");
                txtDiaChi.Text = row.Cells["DiaChi"].Value.ToString(); 
                txtGioiTinh.Text = row.Cells["GioiTinh"].Value.ToString(); 
                txtChucVu.Text = row.Cells["ChucVu"].Value.ToString(); 
                txtSoGioLam.Text = row.Cells["SoGioLam"].Value.ToString(); 
                txtMucLuong.Text = row.Cells["MucLuong"].Value.ToString(); 
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                DTONhanVien nhanVien = new DTONhanVien
                {
                    MaNV = txtMaNV.Text,
                    HoTen = txtHoTen.Text,
                    SDT = txtSDT.Text,
                    NgaySinh = DateTime.Parse(txtNgaySinh.Text),
                    DiaChi = txtDiaChi.Text,
                    GioiTinh = txtGioiTinh.Text,
                    ChucVu = txtChucVu.Text,
                    SoGioLam = int.Parse(txtSoGioLam.Text),
                    MucLuong = decimal.Parse(txtMucLuong.Text)
                };

                if (bLLNhanVien.Add_NhanVien(nhanVien))
                {
                    MessageBox.Show("Thêm nhân viên thành công!");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Thêm nhân viên thất bại!");
                }
            }
            catch (FormatException ex)
            { 
                MessageBox.Show($"Định dạng dữ liệu không hợp lệ: {ex.Message}");
            }

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                string maNV = txtMaNV.Text;

                if (bLLNhanVien.Delete_NhanVien(maNV))
                {
                    MessageBox.Show("Xóa nhân viên thành công!");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Xóa nhân viên thất bại!");
                }
            }
            catch (Exception ex) 
            { 
                MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}");
            }

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                DTONhanVien nhanVien = new DTONhanVien
                {
                    MaNV = txtMaNV.Text,
                    HoTen = txtHoTen.Text,
                    SDT = txtSDT.Text,
                    NgaySinh = DateTime.Parse(txtNgaySinh.Text),
                    DiaChi = txtDiaChi.Text,
                    GioiTinh = txtGioiTinh.Text,
                    ChucVu = txtChucVu.Text,
                    SoGioLam = int.Parse(txtSoGioLam.Text),
                    MucLuong = decimal.Parse(txtMucLuong.Text)
                };

                if (bLLNhanVien.Update_NhanVien(nhanVien))
                {
                    MessageBox.Show("Cập nhật nhân viên thành công!");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Cập nhật nhân viên thất bại!");
                }
            }
            catch (FormatException ex)
            {
                MessageBox.Show($"Định dạng dữ liệu không hợp lệ: {ex.Message}");
            }

        }
        private void btnMoi_Click(object sender, EventArgs e)
        {
            // Xóa dữ liệu trong các ô nhập liệu
            txtMaNV.Clear();
            txtHoTen.Clear(); 
            txtSDT.Clear();
            txtNgaySinh.Clear(); 
            txtDiaChi.Clear();
            txtGioiTinh.Clear(); 
            txtChucVu.Clear();
            txtSoGioLam.Clear(); 
            txtMucLuong.Clear(); 
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
