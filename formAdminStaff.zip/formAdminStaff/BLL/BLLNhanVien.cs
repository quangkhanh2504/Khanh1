﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class BLLNhanVien
    {
        private DALNhanVien dalNhanVien = new DALNhanVien();
        
        public List<DTONhanVien> Get_AllNhanVien()
        {
            return dalNhanVien.Get_NhanVien();
        }
        
        public bool Add_NhanVien(DTONhanVien nhanVien) 
        {
            return dalNhanVien.Add_NhanVien(nhanVien); 
        }
        public bool Update_NhanVien(DTONhanVien nhanVien) 
        { 
            return dalNhanVien.Update_NhanVien(nhanVien);
        }
        public bool Delete_NhanVien(string maNV) 
        { 
            return dalNhanVien.Delete_NhanVien(maNV);
        }
    }
}
