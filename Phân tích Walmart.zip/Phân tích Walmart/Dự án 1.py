# 1. Tải các thư viện cần thiết
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# 2. Tải dữ liệu
df = pd.read_csv("Walmart_Sales.csv")

# 3. Khám phá dữ liệu
# Hiển thị 5 dòng đầu tiên của DataFrame.
print(df.head())
# df.info(): Cung cấp thông tin về các cột trong DataFrame.
print(df.info())
# df.isnull().sum(): Đếm số lượng dữ liệu thiếu trong mỗi cột.
print(df.isnull().sum())

# 4. Làm sạch dữ liệu
# df.sort_values(): Sắp xếp DataFrame theo một hoặc nhiều cột. Ở đây, dữ liệu được sắp xếp trước theo cột Store và sau đó theo cột Date.
df = df.sort_values(by=['Store', 'Date'])

# Chuyển đổi cột "Date" về định dạng datetime để xử lý ngày tháng dễ hơn
df['Date'] = pd.to_datetime(df['Date'], dayfirst=True)

# Làm tròn các cột số liệu để tránh các giá trị thập phân không cần thiết
# .round(): Làm tròn các giá trị trong cột theo số lượng chữ số thập phân mong muốn.
df['Weekly_Sales'] = df['Weekly_Sales'].round(2)  
df['Temperature'] = df['Temperature'].round()  
df['Fuel_Price'] = df['Fuel_Price'].round(2) 
df['CPI'] = df['CPI'].round(3)  
df['Unemployment'] = df['Unemployment'].round(3) 

# df.isnull().sum(): Kiểm tra lại dữ liệu thiếu sau khi đã thực hiện làm sạch dữ liệu để đảm bảo không có dữ liệu nào bị thiếu.
print(df.isnull().sum())

# 5. Phân tích câu hỏi kinh doanh

# Phân tích doanh số hàng tuần vào những ngày lễ
holiday_sales = df[df['Holiday_Flag'] == 1].groupby('Date')['Weekly_Sales'].sum()

# # Tìm cửa hàng có tỷ lệ thất nghiệp thấp nhất và cao nhất
# Thấp nhất: 
lowest_unemployment_store = df.loc[df['Unemployment'].idxmin()]
print(f"Cửa hàng có tỷ lệ thất nghiệp thấp nhất: \n{lowest_unemployment_store}")

# Cao nhất: 
highest_unemployment_store = df.loc[df['Unemployment'].idxmax()]
print(f"Cửa hàng có tỷ lệ thất /nghiệp cao nhất: \n{highest_unemployment_store}")

# Biểu đồ doanh số trung bình hàng tuần theo từng cửa hàng
plt.figure(figsize=(12, 6))
df.groupby('Store')['Weekly_Sales'].mean().plot(kind='bar', color='skyblue')
plt.title('Doanh số trung bình hàng tuần theo cửa hàng')
plt.xlabel('Cửa hàng')
plt.ylabel('Doanh số trung bình hàng tuần')
plt.show()






